This software is released under the MIT License, see LICENSE.

1 ・This library is designed to visualize the frequency of recent earthquakes (seismic intensity 3 or higher).
Enter the path of the Chrome driver as an argument to visualize a bar graph of the frequency.